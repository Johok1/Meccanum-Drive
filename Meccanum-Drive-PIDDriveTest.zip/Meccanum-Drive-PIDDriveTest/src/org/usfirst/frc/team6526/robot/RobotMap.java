
package org.usfirst.frc.team6526.robot;



public class RobotMap {
	
	//PWM
	public static int fright = 2;
	public static int fleft = 1;
	public static int rright = 0;
	public static int rleft = 3;
	
	//Analog Ports 	
	public static int ultrasonic = 0;
	//Assumption alert ^ 
	
	//Serial Connections
	
	//Other Connections  
	
	//Digital Ports
	
	//Other
	public static int US1 = 0;
				
}
